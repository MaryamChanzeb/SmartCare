﻿using Microsoft.AspNetCore.Mvc;
using SmartClinicManagement.Application.DTOs.Patients;
using SmartClinicManagement.Application.Interfaces;

namespace SmartClinicManagement.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PatientsController : ControllerBase
{
    private readonly IPatientService _patientService;

    public PatientsController(IPatientService patientService)
    {
        _patientService = patientService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var patients = await _patientService.GetAllAsync();
        return Ok(patients);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var patient = await _patientService.GetByIdAsync(id);

        if (patient == null)
            return NotFound();

        return Ok(patient);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreatePatientDto dto)
    {
        await _patientService.CreateAsync(dto);

        return Ok(new
        {
            Message = "Patient created successfully."
        });
    }

    // POST: api/Patients/register
    // Combined flow: creates the User account and Patient profile together
    // in one operation, with an optional assigned doctor. This is the one
    // proper patient registration flow — the receptionist never has to
    // pick an existing user from a dropdown.
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterPatientDto dto)
    {
        await _patientService.RegisterPatientAsync(dto);

        return Ok(new
        {
            Message = "Patient registered successfully."
        });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdatePatientDto dto)
    {
        await _patientService.UpdateAsync(id, dto);

        return Ok(new
        {
            Message = "Patient updated successfully."
        });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _patientService.DeleteAsync(id);

        return Ok(new
        {
            Message = "Patient deleted successfully."
        });
    }
}