﻿using Microsoft.AspNetCore.Mvc;
using SmartClinicManagement.Application.DTOs.Appointments;
using SmartClinicManagement.Application.Interfaces;

namespace SmartClinicManagement.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AppointmentsController : ControllerBase
{
    private readonly IAppointmentService _appointmentService;

    public AppointmentsController(IAppointmentService appointmentService)
    {
        _appointmentService = appointmentService;
    }

    // GET: api/Appointments
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var appointments = await _appointmentService.GetAllAppointmentsAsync();

        return Ok(appointments);
    }

    // GET: api/Appointments/5
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var appointment = await _appointmentService.GetAppointmentByIdAsync(id);

        if (appointment == null)
            return NotFound(new
            {
                Message = "Appointment not found."
            });

        return Ok(appointment);
    }
    [HttpPut("{id}/confirm")]
    public async Task<IActionResult> Confirm(int id)
    {
        await _appointmentService.ConfirmAppointmentAsync(id);

        return Ok(new
        {
            message = "Appointment confirmed successfully."
        });
    }

    // POST: api/Appointments
    [HttpPost]
    public async Task<IActionResult> BookAppointment(BookAppointmentDto dto)
    {
        await _appointmentService.BookAppointmentAsync(dto);

        return Ok(new
        {
            Message = "Appointment booked successfully."
        });
    }

    // PUT: api/Appointments/5
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateAppointment(int id, UpdateAppointmentDto dto)
    {
        await _appointmentService.UpdateAppointmentAsync(id, dto);

        return Ok(new
        {
            Message = "Appointment updated successfully."
        });
    }

    // PUT: api/Appointments/5/cancel
    [HttpPut("{id}/cancel")]
    public async Task<IActionResult> CancelAppointment(int id)
    {
        await _appointmentService.CancelAppointmentAsync(id);

        return Ok(new
        {
            Message = "Appointment cancelled successfully."
        });
    }
}