﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartClinicManagement.Application.DTOs.Billing;
using SmartClinicManagement.Application.Interfaces;

namespace SmartClinicManagement.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class BillingController : ControllerBase
{
    private readonly IBillingService _billingService;

    public BillingController(IBillingService billingService)
    {
        _billingService = billingService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var result = await _billingService.GetAllAsync();
        return Ok(result);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await _billingService.GetByIdAsync(id);

        if (result == null)
            return NotFound();

        return Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateBillingDto dto)
    {
        var result = await _billingService.CreateAsync(dto);

        return CreatedAtAction(nameof(GetById),
            new { id = result.BillID }, result);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateBillingDto dto)
    {
        var result = await _billingService.UpdateAsync(id, dto);

        if (!result)
            return NotFound();

        return Ok("Bill Updated Successfully");
    }

    [HttpPut("{id}/pay")]
    public async Task<IActionResult> MarkAsPaid(
        int id,
        MarkBillPaidDto dto)
    {
        var result = await _billingService.MarkAsPaidAsync(id, dto);

        if (!result)
            return NotFound();

        return Ok("Payment Received Successfully");
    }
}