import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { DashboardModel } from '../models/dashboard.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  private apiUrl = 'https://localhost:7006/api/Dashboard';

  constructor(private http: HttpClient) { }

  getDashboard(): Observable<DashboardModel> {
    return this.http.get<DashboardModel>(this.apiUrl);
  }

}
