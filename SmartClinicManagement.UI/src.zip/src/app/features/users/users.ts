import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';

import { UserService } from '../../core/services/user.service';
import { DepartmentService } from '../../core/services/department.service';
import { RoleService } from '../../core/services/role.service';
import { ToastService } from '../../core/services/toast.service';
import { ConfirmDialogService } from '../../core/services/confirm-dialog.service';

import { UserModel, CreateUserModel, UpdateUserModel } from '../../core/models/user.model';
import { DepartmentModel } from '../../core/models/department.model';
import { RoleModel } from '../../core/models/role.model';

@Component({
  selector: 'app-users',
  standalone: false,
  templateUrl: './users.html',
  styleUrls: ['./users.css']
})
export class Users implements OnInit {

  users: UserModel[] = [];
  departments: DepartmentModel[] = [];
  roles: RoleModel[] = [];

  userForm: FormGroup;

  showForm = false;
  loading = false;
  errorMessage = '';

  editingId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private departmentService: DepartmentService,
    private roleService: RoleService,
    private toastService: ToastService,
    private confirmDialog: ConfirmDialogService,
    private cdr: ChangeDetectorRef
  ) {

    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      gender: [''],
      dateOfBirth: [''],
      departmentID: [null],
      roleID: [null],
      status: ['Active']
    });

  }

  ngOnInit(): void {

    this.loadUsers();
    this.loadDepartments();
    this.loadRoles();

  }


  loadUsers(): void {

    this.loading = true;

    this.userService.getAllUsers().subscribe({

      next: (response: UserModel[]) => {

        this.users = response;

        this.loading = false;

        this.cdr.detectChanges();

      },

      error: (err) => {

        console.error(err);

        this.loading = false;

        this.errorMessage = 'Unable to load users.';

        this.cdr.detectChanges();

      }

    });

  }


  loadDepartments(): void {

    this.departmentService.getAllDepartments().subscribe({

      next: (response: DepartmentModel[]) => {

        this.departments = response;

        this.cdr.detectChanges();

      },

      error: (err) => console.error(err)

    });

  }


  loadRoles(): void {

    this.roleService.getAllRoles().subscribe({

      next: (response: RoleModel[]) => {

        this.roles = response;

        this.cdr.detectChanges();

      },

      error: (err) => console.error(err)

    });

  }


  // OPEN CREATE FORM

  openCreateForm(): void {

    this.editingId = null;

    this.userForm.reset({ status: 'Active' });

    this.showForm = true;

  }


  // EDIT USER

  editUser(user: UserModel): void {

    this.editingId = user.userID;

    this.userForm.patchValue({

      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      phone: user.phone,
      gender: user.gender,
      dateOfBirth: user.dateOfBirth ? user.dateOfBirth.substring(0, 10) : '',
      departmentID: this.findDepartmentIdByName(user.departmentName),
      roleID: this.findRoleIdByName(user.roleName),
      status: user.status

    });

    this.showForm = true;

  }


  private findDepartmentIdByName(name?: string): number | null {

    const match = this.departments.find(d => d.departmentName === name);

    return match ? match.departmentID : null;

  }


  private findRoleIdByName(name?: string): number | null {

    const match = this.roles.find(r => r.roleName === name);

    return match ? match.roleID : null;

  }


  saveUser(): void {

    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      return;
    }

    const formValue = this.userForm.value;

    // UPDATE

    if (this.editingId !== null) {

      const updateData: UpdateUserModel = {

        firstName: formValue.firstName,
        lastName: formValue.lastName,
        email: formValue.email,
        phone: formValue.phone,
        gender: formValue.gender,
        // An empty string here fails backend DateOnly? model binding
        // (it isn't valid JSON for a date), which silently broke Update
        // for any user with no birth date set. Send undefined instead so
        // it's omitted from the request body.
        dateOfBirth: formValue.dateOfBirth || undefined,
        departmentID: formValue.departmentID,
        roleID: formValue.roleID,
        status: formValue.status

      };

      this.userService
        .updateUser(this.editingId, updateData)
        .subscribe({

          next: () => {

            this.cancelForm();

            this.loadUsers();

          },

          error: (error) => {

            console.error('Update User Error:', error);

            this.errorMessage = error?.error?.Message || error?.error?.message || 'Unable to update user.';

            this.cdr.detectChanges();

          }

        });

      return;
    }

    // CREATE

    const createData: CreateUserModel = {

      firstName: formValue.firstName,
      lastName: formValue.lastName,
      email: formValue.email,
      phone: formValue.phone,
      gender: formValue.gender,
      dateOfBirth: formValue.dateOfBirth || undefined,
      departmentID: formValue.departmentID,
      roleID: formValue.roleID

    };

    this.userService
      .createUser(createData)
      .subscribe({

        next: () => {

          this.cancelForm();

          this.loadUsers();

          this.toastService.success(
            `User created successfully. Login credentials have been emailed to ${createData.email}.`
          );

        },

        error: (error) => {

          console.error('Create User Error:', error);

          this.errorMessage = error?.error?.Message || error?.error?.message || 'Unable to create user.';

          this.cdr.detectChanges();

        }

      });

  }


  cancelForm(): void {

    this.showForm = false;

    this.editingId = null;

    this.userForm.reset({ status: 'Active' });

  }


  deleteUser(id: number): void {

    this.confirmDialog
      .confirm('Are you sure you want to delete this user?', { title: 'Delete User' })
      .then((confirmed) => {

        if (!confirmed) return;

        this.userService
          .deleteUser(id)
          .subscribe({

            next: () => {


              this.loadUsers();

              this.toastService.success('User deleted successfully.');

            },

            error: (error) => {

              console.error('Delete User Error:', error);

              this.errorMessage = error?.error?.Message || error?.error?.message || 'Unable to delete user.';

              this.toastService.error(this.errorMessage);

              this.cdr.detectChanges();

            }

          });

      });

  }

}
