import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-forgot-password',
  standalone: false,
  templateUrl: './forgot-password.html',
  styleUrl: './forgot-password.css'
})
export class ForgotPassword {

  forgotForm: FormGroup;

  submitting = false;
  submitted = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private toastService: ToastService
  ) {

    this.forgotForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });

  }

  onSubmit(): void {

    if (this.forgotForm.invalid) {
      this.forgotForm.markAllAsTouched();
      return;
    }

    this.submitting = true;

    this.authService.forgotPassword(this.forgotForm.value).subscribe({

      next: (response) => {

        this.submitting = false;
        this.submitted = true;
        this.toastService.success(response.message);

      },

      error: (error) => {

        this.submitting = false;
        console.error('Forgot Password Error:', error);
        this.toastService.error('Something went wrong. Please try again.');

      }

    });

  }

}
